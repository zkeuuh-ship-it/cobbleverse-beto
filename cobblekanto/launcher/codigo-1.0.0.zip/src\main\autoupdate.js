/**
 * Atualizacao automatica do proprio launcher.
 *
 * Baixa um pacote pequeno (so o codigo, ~100 KB) publicado no GitHub, confere o SHA-256
 * e deixa pronto em %APPDATA%\CobbleKanto-Beto\launcher-code\atual. A troca vale na
 * proxima vez que o launcher abrir - nada e substituido enquanto o programa roda, e
 * nada e gravado na pasta de instalacao (por isso nao pede permissao de administrador).
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { P } = require('./paths');
const { download, getJSON, hashFile } = require('./net');
const { extractZip } = require('./zip');

const BASE = 'https://raw.githubusercontent.com/zkeuuh-ship-it/cobbleverse-beto/main/cobblekanto/launcher/';
const INFO = BASE + 'codigo.json';

const pastaCodigo = () => path.join(P.root, 'launcher-code');

function maior(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return true;
    if ((pa[i] || 0) < (pb[i] || 0)) return false;
  }
  return false;
}

/**
 * Procura uma versao nova. Nunca derruba o launcher: qualquer problema vira so um aviso.
 * Retorna { atualizou: bool, versao } - quando true, vale a partir do proximo boot.
 */
async function verificarAtualizacao(versaoAtual, log) {
  try {
    const info = await getJSON(INFO + '?t=' + Date.now());
    if (!info || !info.versao || !info.arquivo || !info.sha256) return { atualizou: false };
    if (!maior(info.versao, versaoAtual)) return { atualizou: false, versao: versaoAtual };

    log('Baixando atualizacao do launcher (' + info.versao + ')...');
    const destino = pastaCodigo();
    const zipPath = path.join(P.cache, 'launcher-' + info.versao + '.zip');
    await download(BASE + info.arquivo, zipPath, { sha256: info.sha256, tries: 3 });

    // confere de novo o arquivo ja gravado antes de confiar nele
    if ((await hashFile(zipPath, 'sha256')) !== String(info.sha256).toLowerCase()) {
      throw new Error('o pacote baixado nao confere');
    }

    const temp = path.join(destino, 'novo');
    fs.rmSync(temp, { recursive: true, force: true });
    fs.mkdirSync(temp, { recursive: true });
    await extractZip(zipPath, temp);

    // so troca se o pacote tiver mesmo o que precisa para rodar
    const precisa = [path.join(temp, 'package.json'), path.join(temp, 'src', 'main', 'main.js'), path.join(temp, 'src', 'renderer', 'index.html'),
                     path.join(temp, 'node_modules', 'yauzl', 'package.json')];
    for (const p of precisa) {
      if (!fs.existsSync(p)) throw new Error('pacote incompleto (' + path.basename(p) + ')');
    }

    const atual = path.join(destino, 'atual');
    fs.rmSync(atual, { recursive: true, force: true });
    fs.renameSync(temp, atual);
    try { fs.unlinkSync(zipPath); } catch (e) {}

    log('Launcher atualizado para ' + info.versao + '. Vai valer quando voce fechar e abrir de novo.');
    return { atualizou: true, versao: info.versao, notas: info.notas || '' };
  } catch (e) {
    log('Nao consegui verificar atualizacao do launcher (' + e.message + '). Seguindo normalmente.');
    return { atualizou: false };
  }
}

module.exports = { verificarAtualizacao };

const path = require('path');
const fs = require('fs');
const os = require('os');

// Tudo do launcher fica isolado, sem tocar no .minecraft do jogador
const ROOT = path.join(process.env.APPDATA || os.homedir(), 'CobbleKanto-Beto');

const P = {
  root: ROOT,
  game: path.join(ROOT, 'game'),               // gameDir: mods, config, saves...
  mods: path.join(ROOT, 'game', 'mods'),
  mc: path.join(ROOT, 'minecraft'),            // versions/libraries/assets
  versions: path.join(ROOT, 'minecraft', 'versions'),
  libraries: path.join(ROOT, 'minecraft', 'libraries'),
  assets: path.join(ROOT, 'minecraft', 'assets'),
  natives: path.join(ROOT, 'minecraft', 'natives'),
  runtime: path.join(ROOT, 'runtime'),
  cache: path.join(ROOT, 'cache'),
  logs: path.join(ROOT, 'logs'),
  config: path.join(ROOT, 'launcher.json'),
  state: path.join(ROOT, 'estado.json')
};

function ensureDirs() {
  for (const k of ['root', 'game', 'mods', 'mc', 'versions', 'libraries', 'assets', 'natives', 'runtime', 'cache', 'logs']) {
    fs.mkdirSync(P[k], { recursive: true });
  }
}

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
}
function writeJSON(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 1));
}

module.exports = { P, ensureDirs, readJSON, writeJSON };

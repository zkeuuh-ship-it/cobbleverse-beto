const $ = id => document.getElementById(id);
let conta = null;
let estado = null;
let jogando = false;

// ---------- janela ----------
$('btn-min').onclick = () => api.janela('minimizar');
$('btn-fechar').onclick = () => api.janela('fechar');

// ---------- mensagens (uma linha; o detalhe vai para o arquivo de relatorio) ----------
function status(txt, erro) {
  const el = $('status-linha');
  el.textContent = txt || '';
  el.classList.toggle('erro-txt', !!erro);
}
api.ao('log', t => status(t, /ERRO|Falha|Nao consegui|Não consegui/i.test(t)));
api.ao('log-jogo', () => {});

api.ao('progresso', p => {
  $('caixa-progresso').classList.remove('oculto');
  const pct = Math.max(0, Math.min(100, p.pct));
  $('barra').style.width = pct + '%';
  $('pokebola').style.left = Math.max(2, Math.min(98, pct)) + '%';
  $('progresso-texto').textContent = p.texto || p.etapa;
  $('progresso-mb').textContent = p.mb + ' MB';
});

api.ao('launcher-atualizado', info => {
  $('aviso-update').classList.remove('oculto');
  $('aviso-update-txt').textContent = info.reabrindo
    ? 'Launcher atualizado (versão ' + info.versao + '). Reabrindo sozinho, um instante...'
    : 'Launcher atualizado (versão ' + info.versao + '). Vai valer na próxima vez que você abrir.';
});

api.ao('jogo-fechou', info => {
  jogando = false;
  $('jogar').disabled = false;
  $('jogar-sub').textContent = 'instalar e entrar no servidor';
  $('caixa-progresso').classList.add('oculto');
  if (info.code === 0 || info.code === null) status('O jogo foi fechado.');
  else status('O jogo fechou com erro. Veja em Relatórios.', true);
});

// ---------- inicio ----------
async function iniciar() {
  estado = await api.estado();
  $('ip-servidor').textContent = estado.servidor.host + ':' + estado.servidor.port;
  $('pk-versao').textContent = estado.pack.versao;
  $('pk-mc').textContent = estado.pack.mc;
  $('pk-loader').textContent = estado.pack.loader;
  $('pk-mods').textContent = estado.pack.mods + ' mods';
  if (estado.versaoLauncher) $('barra-versao').textContent = 'v' + estado.versaoLauncher;

  const r = $('ram');
  r.max = Math.min(16384, Math.max(4096, estado.ramMaximaMB));
  r.value = estado.config.ramMB;
  mostrarRam();
  $('entrar-direto').checked = estado.config.entrarDireto;
  $('minimizar').checked = estado.config.fecharAoJogar;
  $('nick').value = estado.config.nickOffline || '';

  atualizarPing();
  setInterval(atualizarPing, 20000);

  if (estado.contaSalva) {
    $('erro-login').textContent = 'Reconectando a conta ' + estado.contaSalva.nome + '...';
    const res = await api.loginSilencioso();
    if (res.ok) return entrar(res.conta);
    $('erro-login').textContent = '';
  }
}

function mostrarRam() {
  const v = parseInt($('ram').value, 10);
  $('ram-valor').textContent = (v / 1024).toFixed(1).replace('.0', '') + ' GB';
}

async function atualizarPing() {
  const s = await api.ping();
  const b = $('status-bolha');
  if (s.online) {
    b.textContent = 'online';
    b.className = 'bolha bolha-on';
    $('st-jogadores').textContent = s.jogadores + '/' + s.maximo;
    $('st-ping').textContent = s.ms + 'ms';
    $('st-versao').textContent = s.versao || '—';
    $('lista-jogadores').textContent = s.lista && s.lista.length ? 'Jogando agora: ' + s.lista.join(', ') : '';
  } else {
    b.textContent = 'offline';
    b.className = 'bolha bolha-off';
    $('st-jogadores').textContent = '—';
    $('st-ping').textContent = '—';
    $('st-versao').textContent = '—';
    $('lista-jogadores').textContent = '';
  }
}

// ---------- login ----------
$('op-ms').onclick = async () => {
  $('erro-login').textContent = 'Abrindo o login da Microsoft...';
  $('op-ms').disabled = true;
  const res = await api.loginMS();
  $('op-ms').disabled = false;
  if (res.ok) entrar(res.conta);
  else $('erro-login').textContent = res.erro;
};

$('op-offline').onclick = async () => {
  const res = await api.loginOffline($('nick').value);
  if (res.ok) entrar(res.conta);
  else $('erro-login').textContent = res.erro;
};
$('nick').addEventListener('keydown', e => { if (e.key === 'Enter') $('op-offline').click(); });

function entrar(c) {
  conta = c;
  $('tela-login').classList.add('oculto');
  $('tela-principal').classList.remove('oculto');
  $('usuario-nome').textContent = c.nome;
  $('usuario-tipo').textContent = c.tipo === 'microsoft' ? 'Conta Microsoft (original)' : 'Conta local';
  $('avatar').textContent = c.nome.charAt(0).toUpperCase();
  $('nick-servidor').textContent = c.nome;
  status('Bem-vindo, ' + c.nome + '!');
}

// ---------- ajustes ----------
$('ram').addEventListener('input', mostrarRam);
$('ram').addEventListener('change', () => api.salvarConfig({ ramMB: parseInt($('ram').value, 10) }));
$('entrar-direto').addEventListener('change', e => api.salvarConfig({ entrarDireto: e.target.checked }));
$('minimizar').addEventListener('change', e => api.salvarConfig({ fecharAoJogar: e.target.checked }));
$('copiar-ip').onclick = () => {
  navigator.clipboard.writeText($('ip-servidor').textContent);
  $('copiar-ip').textContent = 'copiado!';
  setTimeout(() => ($('copiar-ip').textContent = 'copiar'), 1500);
};
$('abrir-pasta').onclick = () => api.abrirPasta('jogo');
$('abrir-logs').onclick = () => api.abrirPasta('logs');
$('reparar').onclick = async () => {
  if (await api.reparar()) status('Marcado para reparo. Clique em JOGAR para baixar tudo de novo.');
};
$('trocar-conta').onclick = async () => {
  await api.sairConta();
  conta = null;
  $('tela-principal').classList.add('oculto');
  $('tela-login').classList.remove('oculto');
  $('erro-login').textContent = '';
};

// ---------- jogar ----------
$('jogar').onclick = async () => {
  if (jogando || !conta) return;
  jogando = true;
  $('jogar').disabled = true;
  $('jogar-sub').textContent = 'preparando...';
  const res = await api.jogar(conta);
  if (!res.ok) {
    jogando = false;
    $('jogar').disabled = false;
    $('jogar-sub').textContent = 'instalar e entrar no servidor';
    $('caixa-progresso').classList.add('oculto');
    status('Não deu certo: ' + res.erro, true);
  } else {
    $('jogar-sub').textContent = 'jogo aberto';
  }
};

iniciar();

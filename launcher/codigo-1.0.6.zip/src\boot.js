/**
 * Ponto de entrada do launcher.
 *
 * O codigo do launcher pode se atualizar sozinho. Como o programa costuma ficar
 * instalado em "C:\Program Files" (onde so o administrador escreve), a atualizacao
 * NAO mexe na pasta de instalacao: ela fica em %APPDATA%\COBBLEVERSE-Beto\launcher-code.
 * Aqui decidimos qual dos dois codigos rodar - o que veio no .exe ou o atualizado.
 */
const path = require('path');
const fs = require('fs');
const os = require('os');

const RAIZ = path.join(process.env.APPDATA || os.homedir(), 'COBBLEVERSE-Beto');
const PASTA_ATUALIZADA = path.join(RAIZ, 'launcher-code', 'atual');

function versaoDe(arquivoPackage) {
  try { return JSON.parse(fs.readFileSync(arquivoPackage, 'utf8')).version || null; }
  catch (e) { return null; }
}

/** compara "1.2.10" com "1.2.9" numericamente */
function maior(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return true;
    if ((pa[i] || 0) < (pb[i] || 0)) return false;
  }
  return false;
}

function escolherCodigo() {
  const embutido = path.join(__dirname, 'main', 'main.js');
  try {
    const vEmbutida = versaoDe(path.join(__dirname, '..', 'package.json')) || '0.0.0';
    const vAtualizada = versaoDe(path.join(PASTA_ATUALIZADA, 'package.json'));
    const entradaAtualizada = path.join(PASTA_ATUALIZADA, 'src', 'main', 'main.js');
    if (vAtualizada && maior(vAtualizada, vEmbutida) && fs.existsSync(entradaAtualizada)) {
      return { arquivo: entradaAtualizada, versao: vAtualizada, atualizado: true };
    }
    return { arquivo: embutido, versao: vEmbutida, atualizado: false };
  } catch (e) {
    return { arquivo: embutido, versao: '0.0.0', atualizado: false };
  }
}

const escolha = escolherCodigo();
process.env.COBBLEVERSE_VERSAO = escolha.versao;
process.env.COBBLEVERSE_CODIGO_ATUALIZADO = escolha.atualizado ? '1' : '0';

try {
  require(escolha.arquivo);
} catch (erro) {
  // se a versao atualizada estiver com problema, volta para a que veio no .exe
  if (escolha.atualizado) {
    try { fs.rmSync(PASTA_ATUALIZADA, { recursive: true, force: true }); } catch (e) {}
    process.env.COBBLEVERSE_CODIGO_ATUALIZADO = '0';
    require(path.join(__dirname, 'main', 'main.js'));
  } else {
    throw erro;
  }
}

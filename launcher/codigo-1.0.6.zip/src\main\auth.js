const crypto = require('crypto');
const { BrowserWindow, safeStorage } = require('electron');
const { P, readJSON, writeJSON } = require('./paths');

// client_id publico do launcher da Mojang (fluxo usado por launchers alternativos)
const CLIENT_ID = '00000000402b5328';
const REDIRECT = 'https://login.live.com/oauth20_desktop.srf';
const SCOPE = 'service::user.auth.xboxlive.com::MBI_SSL';

const UA = 'COBBLEVERSE-Beto-Launcher/1.0';

function authorizeUrl() {
  const q = new URLSearchParams({
    client_id: CLIENT_ID, response_type: 'code', redirect_uri: REDIRECT,
    scope: SCOPE, prompt: 'select_account'
  });
  return 'https://login.live.com/oauth20_authorize.srf?' + q.toString();
}

async function form(url, data) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': UA },
    body: new URLSearchParams(data).toString()
  });
  const txt = await res.text();
  let json; try { json = JSON.parse(txt); } catch (e) { json = { raw: txt }; }
  if (!res.ok) throw new Error((json.error_description || json.error || 'erro ' + res.status));
  return json;
}

async function postJSON(url, body, headers = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': UA, ...headers },
    body: JSON.stringify(body)
  });
  const txt = await res.text();
  let json; try { json = JSON.parse(txt); } catch (e) { json = { raw: txt }; }
  if (!res.ok) { const err = new Error('HTTP ' + res.status); err.data = json; err.status = res.status; throw err; }
  return json;
}

/** Abre a janela da Microsoft e devolve o code do redirect. */
function pedirCodigo(parent) {
  return new Promise((resolve, reject) => {
    const win = new BrowserWindow({
      width: 520, height: 720, parent, modal: true, show: true,
      autoHideMenuBar: true, title: 'Entrar com a conta Microsoft',
      webPreferences: { nodeIntegration: false, contextIsolation: true, partition: 'persist:mslogin' }
    });
    let terminou = false;
    const checar = url => {
      if (terminou) return;
      if (!url.startsWith(REDIRECT)) return;
      const u = new URL(url);
      const code = u.searchParams.get('code');
      const erro = u.searchParams.get('error');
      terminou = true;
      win.destroy();
      if (code) resolve(code);
      else reject(new Error(erro === 'access_denied' ? 'Login cancelado.' : (erro || 'Login nao concluido.')));
    };
    win.webContents.on('will-redirect', (e, url) => checar(url));
    win.webContents.on('will-navigate', (e, url) => checar(url));
    win.on('closed', () => { if (!terminou) { terminou = true; reject(new Error('Janela de login fechada.')); } });
    win.loadURL(authorizeUrl());
  });
}

async function xboxParaMinecraft(msAccessToken) {
  const xbl = await postJSON('https://user.auth.xboxlive.com/user/authenticate', {
    Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: msAccessToken },
    RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT'
  });
  const uhs = xbl.DisplayClaims.xui[0].uhs;

  let xsts;
  try {
    xsts = await postJSON('https://xsts.auth.xboxlive.com/xsts/authorize', {
      Properties: { SandboxId: 'RETAIL', UserTokens: [xbl.Token] },
      RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT'
    });
  } catch (e) {
    const x = e.data && (e.data.XErr || e.data.xErr);
    if (String(x) === '2148916233') throw new Error('Esta conta Microsoft nao tem um perfil Xbox. Crie um em xbox.com e tente de novo.');
    if (String(x) === '2148916238') throw new Error('Conta infantil: precisa ser adicionada a um Grupo Familiar para jogar.');
    if (String(x) === '2148916235') throw new Error('Conta de um pais/regiao onde o Xbox Live nao esta disponivel.');
    throw new Error('A Microsoft recusou o login do Xbox Live.' + (x ? ' (codigo ' + x + ')' : ''));
  }

  const mc = await postJSON('https://api.minecraftservices.com/authentication/login_with_xbox', {
    identityToken: 'XBL3.0 x=' + uhs + ';' + xsts.Token
  });

  const res = await fetch('https://api.minecraftservices.com/minecraft/profile', {
    headers: { Authorization: 'Bearer ' + mc.access_token, 'User-Agent': UA }
  });
  if (res.status === 404) throw new Error('Esta conta Microsoft nao tem Minecraft Java Edition. Use o modo "sem conta original" ou compre o jogo.');
  if (!res.ok) throw new Error('Nao consegui ler o perfil do Minecraft (erro ' + res.status + ').');
  const perfil = await res.json();

  return {
    tipo: 'microsoft',
    nome: perfil.name,
    uuid: perfil.id.replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5'),
    accessToken: mc.access_token,
    expiraEm: Date.now() + (mc.expires_in || 86400) * 1000
  };
}

async function loginMicrosoft(parentWindow) {
  const code = await pedirCodigo(parentWindow);
  const tk = await form('https://login.live.com/oauth20_token.srf', {
    client_id: CLIENT_ID, code, grant_type: 'authorization_code', redirect_uri: REDIRECT
  });
  const conta = await xboxParaMinecraft(tk.access_token);
  guardarRefresh(tk.refresh_token, conta);
  return conta;
}

/** Tenta reentrar sozinho usando o refresh token guardado. */
async function loginSilencioso() {
  const cfg = readJSON(P.config, {});
  if (!cfg.contaMS || !cfg.contaMS.refresh) return null;
  let refresh;
  try {
    refresh = cfg.contaMS.cripto && safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(cfg.contaMS.refresh, 'base64'))
      : Buffer.from(cfg.contaMS.refresh, 'base64').toString('utf8');
  } catch (e) { return null; }
  try {
    const tk = await form('https://login.live.com/oauth20_token.srf', {
      client_id: CLIENT_ID, refresh_token: refresh, grant_type: 'refresh_token', redirect_uri: REDIRECT
    });
    const conta = await xboxParaMinecraft(tk.access_token);
    guardarRefresh(tk.refresh_token || refresh, conta);
    return conta;
  } catch (e) { return null; }
}

function guardarRefresh(refresh, conta) {
  const cfg = readJSON(P.config, {});
  const podeCripto = safeStorage.isEncryptionAvailable();
  cfg.contaMS = {
    refresh: podeCripto ? safeStorage.encryptString(refresh).toString('base64') : Buffer.from(refresh, 'utf8').toString('base64'),
    cripto: podeCripto,
    nome: conta.nome, uuid: conta.uuid
  };
  writeJSON(P.config, cfg);
}

function esquecerConta() {
  const cfg = readJSON(P.config, {});
  delete cfg.contaMS;
  writeJSON(P.config, cfg);
}

/** Conta sem verificacao (servidor esta em online-mode=false). */
function contaOffline(nome) {
  nome = String(nome || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(nome)) throw new Error('O nick precisa ter de 3 a 16 letras, numeros ou _ (sem espacos nem acentos).');
  const md5 = crypto.createHash('md5').update('OfflinePlayer:' + nome).digest();
  md5[6] = (md5[6] & 0x0f) | 0x30; // versao 3
  md5[8] = (md5[8] & 0x3f) | 0x80; // variante
  const hex = md5.toString('hex');
  const uuid = hex.replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
  return { tipo: 'offline', nome, uuid, accessToken: '0', expiraEm: 0 };
}

module.exports = { loginMicrosoft, loginSilencioso, contaOffline, esquecerConta };

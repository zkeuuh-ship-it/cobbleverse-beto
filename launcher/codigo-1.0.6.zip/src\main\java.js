const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { P } = require('./paths');
const { download, getJSON, pool } = require('./net');
const { extractZip } = require('./zip');

// Runtime oficial que o proprio launcher da Mojang usa (arquivos pequenos, cada um com SHA-1).
// E bem mais resistente a internet ruim do que baixar um zip de 50 MB de uma vez.
const MOJANG_ALL = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
const COMPONENTE = { 21: 'java-runtime-delta', 17: 'java-runtime-gamma', 8: 'jre-legacy' };

function javaVersionOf(exe) {
  return new Promise(resolve => {
    execFile(exe, ['-version'], { timeout: 20000 }, (err, stdout, stderr) => {
      const out = (stderr || '') + (stdout || '');
      const m = out.match(/version "(\d+)(?:\.(\d+))?/);
      if (!m) return resolve(null);
      let major = parseInt(m[1], 10);
      if (major === 1 && m[2]) major = parseInt(m[2], 10); // "1.8.0"
      resolve(major);
    });
  });
}

/** Procura um javaw.exe dentro de uma pasta (nela mesma ou um nivel abaixo). */
function javaEm(base) {
  if (!fs.existsSync(base)) return null;
  const candidatos = [base];
  try {
    for (const d of fs.readdirSync(base)) {
      const p = path.join(base, d);
      if (fs.statSync(p).isDirectory()) candidatos.push(p);
    }
  } catch (e) {}
  for (const d of candidatos) {
    const exe = path.join(d, 'bin', 'javaw.exe');
    if (fs.existsSync(exe)) return exe;
  }
  return null;
}

/** Procura um javaw.exe dentro das pastas que o launcher mesmo instalou. */
function javaInterno() {
  for (const sub of ['mojang-java21', 'java21', 'zulu21']) {
    const exe = javaEm(path.join(P.runtime, sub));
    if (exe) return exe;
  }
  return null;
}

function javaDoSistema() {
  const achados = [];
  const bases = [
    process.env.JAVA_HOME,
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'Java'),
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'Eclipse Adoptium'),
    process.env.ProgramFiles && path.join(process.env.ProgramFiles, 'Microsoft', 'jdk'),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs', 'Eclipse Adoptium')
  ].filter(Boolean);
  for (const b of bases) {
    const direto = path.join(b, 'bin', 'javaw.exe');
    if (fs.existsSync(direto)) achados.push(direto);
    try {
      for (const d of fs.readdirSync(b)) {
        const exe = path.join(b, d, 'bin', 'javaw.exe');
        if (fs.existsSync(exe)) achados.push(exe);
      }
    } catch (e) {}
  }
  return achados;
}

/** Fonte 1: runtime da Mojang, arquivo por arquivo com SHA-1. */
async function baixarDaMojang(major, log, onChunk, tick) {
  const comp = COMPONENTE[major];
  if (!comp) throw new Error('sem runtime da Mojang para o Java ' + major);

  const todos = await getJSON(MOJANG_ALL);
  const entrada = todos['windows-x64'] && todos['windows-x64'][comp] && todos['windows-x64'][comp][0];
  if (!entrada || !entrada.manifest) throw new Error('a Mojang nao listou o Java ' + major);

  const manifesto = await getJSON(entrada.manifest.url);
  const base = path.join(P.runtime, 'mojang-java' + major);
  const itens = Object.entries(manifesto.files);

  for (const [rel, info] of itens) {
    if (info.type === 'directory') fs.mkdirSync(path.join(base, rel), { recursive: true });
  }

  const arquivos = itens.filter(([, info]) => info.type === 'file' && info.downloads && info.downloads.raw);
  log('Instalando o Java ' + (entrada.version && entrada.version.name || major) + ' (' + arquivos.length + ' arquivos)...');

  let feitos = 0;
  await pool(arquivos, async ([rel, info]) => {
    const raw = info.downloads.raw;
    await download(raw.url, path.join(base, rel), { sha1: raw.sha1, size: raw.size, onChunk });
    if (tick) tick(++feitos, arquivos.length);
  }, 8);

  const exe = path.join(base, 'bin', 'javaw.exe');
  if (!fs.existsSync(exe)) throw new Error('o Java foi baixado mas o javaw.exe nao apareceu');
  return exe;
}

/** Fonte 2 (reserva): Temurin da Adoptium, um zip so. */
async function baixarDaAdoptium(major, log, onChunk) {
  const api = 'https://api.adoptium.net/v3/assets/latest/' + major +
    '/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse';
  const lista = await getJSON(api);
  const pacote = lista && lista[0] && lista[0].binary && lista[0].binary.package;
  if (!pacote || !pacote.link) throw new Error('a Adoptium nao ofereceu o Java ' + major);

  const zipPath = path.join(P.cache, 'java' + major + '.zip');
  log('Baixando o Java pela Adoptium (' + Math.round((pacote.size || 0) / 1048576) + ' MB)...');
  await download(pacote.link, zipPath, { size: pacote.size, sha256: pacote.checksum, onChunk });

  const dest = path.join(P.runtime, 'java' + major);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  log('Descompactando o Java...');
  await extractZip(zipPath, dest);
  try { fs.unlinkSync(zipPath); } catch (e) {}

  // procura so dentro do que ACABAMOS de extrair (uma pasta da outra fonte pode estar pela metade)
  const exe = javaEm(dest);
  if (!exe) throw new Error('o Java foi descompactado mas o javaw.exe nao apareceu');
  return exe;
}

/** Fonte 3 (reserva): Azul Zulu - outro CDN, util quando o antivirus implica com os outros. */
async function baixarDoZulu(major, log, onChunk) {
  const busca = 'https://api.azul.com/metadata/v1/zulu/packages/?java_version=' + major +
    '&os=windows&arch=x64&java_package_type=jre&archive_type=zip&latest=true' +
    '&release_status=ga&availability_types=CA&page_size=1';
  const lista = await getJSON(busca);
  const uuid = lista && lista[0] && lista[0].package_uuid;
  if (!uuid) throw new Error('a Azul nao ofereceu o Java ' + major);
  const info = await getJSON('https://api.azul.com/metadata/v1/zulu/packages/' + uuid);
  if (!info.download_url) throw new Error('a Azul nao devolveu o endereco do download');

  const zipPath = path.join(P.cache, 'zulu' + major + '.zip');
  log('Baixando o Java pela Azul (' + Math.round((info.size || 0) / 1048576) + ' MB)...');
  // o tamanho informado pela Azul as vezes difere alguns bytes do arquivo real: confiamos no SHA-256
  await download(info.download_url, zipPath, { sha256: info.sha256_hash, onChunk, timeoutMs: 1800000 });

  const dest = path.join(P.runtime, 'zulu' + major);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  log('Descompactando o Java...');
  await extractZip(zipPath, dest);
  try { fs.unlinkSync(zipPath); } catch (e) {}

  const exe = javaEm(dest);
  if (!exe) throw new Error('o Java foi descompactado mas o javaw.exe nao apareceu');
  return exe;
}

/** Garante um Java utilizavel, tentando a Mojang, a Adoptium e o que ja existe no PC. */
async function ensureJava(major, log, onChunk, tick) {
  const proprio = javaInterno();
  if (proprio) {
    const v = await javaVersionOf(proprio);
    if (v && v >= major) { log('Java ' + v + ' pronto.'); return proprio; }
  }

  for (const cand of javaDoSistema()) {
    const v = await javaVersionOf(cand);
    if (v && v >= major) { log('Usando o Java ' + v + ' que ja esta instalado no PC.'); return cand; }
  }

  log('O jogo precisa do Java ' + major + '. Vou baixar (so na primeira vez).');
  const erros = [];
  const fontes = [['Mojang', baixarDaMojang], ['Adoptium', baixarDaAdoptium], ['Azul', baixarDoZulu]];
  for (const [nome, fonte] of fontes) {
    try {
      const exe = await fonte(major, log, onChunk, tick);
      const v = await javaVersionOf(exe);
      if (!v || v < major) throw new Error('a versao baixada nao serve (Java ' + v + ')');
      log('Java ' + v + ' instalado.');
      return exe;
    } catch (e) {
      erros.push(nome + ': ' + e.message);
      const ultima = nome === fontes[fontes.length - 1][0];
      log('Nao consegui pela ' + nome + ' (' + e.message + ').' + (ultima ? '' : ' Tentando outra fonte...'));
    }
  }
  const alterado = erros.some(x => /diferente do original|nao foi gravado/.test(x));
  let recado = 'Nao consegui instalar o Java ' + major + ' por nenhuma das 3 fontes.';
  if (alterado) {
    recado += ' Os arquivos chegaram diferentes do original, o que quase sempre e o ANTIVIRUS' +
      ' mexendo no download. Abra Seguranca do Windows > Protecao contra virus e ameacas >' +
      ' Gerenciar configuracoes > Exclusoes e adicione esta pasta: ' + P.root;
  } else {
    recado += ' Verifique a conexao com a internet e tente de novo.';
  }
  throw new Error(recado + ' (detalhes: ' + erros.join(' | ') + ')');
}

module.exports = { ensureJava, javaVersionOf, javaInterno, javaDoSistema, baixarDaMojang, baixarDaAdoptium, baixarDoZulu };

const fs = require('fs');
const path = require('path');
const { P } = require('./paths');
const { download, getJSON, pool } = require('./net');
const { extractZip } = require('./zip');

const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const RESOURCES = 'https://resources.download.minecraft.net/';
const FABRIC_META = 'https://meta.fabricmc.net/v2/versions/loader/';

const OS_NAME = 'windows';

function allowed(rules) {
  if (!rules || !rules.length) return true;
  let ok = false;
  for (const r of rules) {
    let applies = true;
    if (r.os) {
      if (r.os.name && r.os.name !== OS_NAME) applies = false;
      if (r.os.arch && r.os.arch !== 'x64' && r.os.arch !== process.arch) applies = false;
    }
    if (r.features) applies = false; // recursos opcionais (demo, resolucao) nao usados
    if (applies) ok = r.action === 'allow';
  }
  return ok;
}

/**
 * As bibliotecas nativas do Windows vem em tres sabores (x64, arm64 e x86) com a MESMA
 * regra "allow windows" - quem diferencia e o sufixo do nome. Sem esse filtro as DLLs
 * de arm64/x86 sobrescrevem as de x64 e o jogo nao acha a lwjgl.dll.
 */
function nativaDestaMaquina(name) {
  const m = /:natives-([\w-]+)$/.exec(name || '');
  if (!m) return true;
  const sabor = m[1];
  if (!sabor.startsWith('windows')) return false;
  if (sabor === 'windows') return process.arch === 'x64';
  if (sabor === 'windows-arm64') return process.arch === 'arm64';
  if (sabor === 'windows-x86') return process.arch === 'ia32';
  return false;
}

function mavenToPath(name) {
  // group:artifact:version[:classifier]
  const parts = name.split(':');
  const [g, a, v] = parts;
  const cls = parts[3] ? '-' + parts[3] : '';
  return g.replace(/\./g, '/') + '/' + a + '/' + v + '/' + a + '-' + v + cls + '.jar';
}

/** Baixa o JSON da versao vanilla e o client.jar */
async function ensureVanilla(mcVersion, log, onChunk) {
  const dir = path.join(P.versions, mcVersion);
  const jsonPath = path.join(dir, mcVersion + '.json');
  let meta;
  if (fs.existsSync(jsonPath)) {
    meta = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
  } else {
    log('Buscando o Minecraft ' + mcVersion + '...');
    const man = await getJSON(MANIFEST);
    const entry = man.versions.find(v => v.id === mcVersion);
    if (!entry) throw new Error('Versao ' + mcVersion + ' nao encontrada na Mojang');
    meta = await getJSON(entry.url);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(jsonPath, JSON.stringify(meta));
  }
  const jar = path.join(dir, mcVersion + '.jar');
  await download(meta.downloads.client.url, jar, { sha1: meta.downloads.client.sha1, size: meta.downloads.client.size, onChunk });
  return { meta, jar };
}

/** Perfil do Fabric (libraries + mainClass) */
async function ensureFabric(mcVersion, loaderVersion, log) {
  const id = 'fabric-loader-' + loaderVersion + '-' + mcVersion;
  const dir = path.join(P.versions, id);
  const jsonPath = path.join(dir, id + '.json');
  if (fs.existsSync(jsonPath)) return JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
  log('Preparando o Fabric ' + loaderVersion + '...');
  const prof = await getJSON(FABRIC_META + mcVersion + '/' + loaderVersion + '/profile/json');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(jsonPath, JSON.stringify(prof));
  return prof;
}

/** Baixa todas as bibliotecas (vanilla + fabric) e extrai as nativas */
async function ensureLibraries(vanillaMeta, fabricProfile, log, onChunk, tick) {
  const jobs = [];
  const classpath = [];
  const nativeJars = [];

  for (const lib of vanillaMeta.libraries) {
    if (!allowed(lib.rules)) continue;
    if (!nativaDestaMaquina(lib.name)) continue;
    const art = lib.downloads && lib.downloads.artifact;
    if (art && art.path) {
      const dest = path.join(P.libraries, art.path.replace(/\//g, path.sep));
      jobs.push({ url: art.url, dest, sha1: art.sha1, size: art.size });
      if (/:natives-/.test(lib.name) || /natives-windows/.test(art.path)) nativeJars.push(dest);
      else classpath.push(dest);
    }
    // formato antigo com classifiers
    const cls = lib.downloads && lib.downloads.classifiers;
    if (cls) {
      const key = (lib.natives && lib.natives[OS_NAME] || '').replace('${arch}', '64');
      const nat = key && cls[key];
      if (nat) {
        const dest = path.join(P.libraries, nat.path.replace(/\//g, path.sep));
        jobs.push({ url: nat.url, dest, sha1: nat.sha1, size: nat.size });
        nativeJars.push(dest);
      }
    }
  }

  for (const lib of (fabricProfile.libraries || [])) {
    if (!allowed(lib.rules)) continue;
    const rel = mavenToPath(lib.name);
    const dest = path.join(P.libraries, rel.replace(/\//g, path.sep));
    const url = lib.url ? (lib.url.replace(/\/$/, '') + '/' + rel) : (lib.downloads && lib.downloads.artifact && lib.downloads.artifact.url);
    if (!url) continue;
    jobs.push({ url, dest, sha1: lib.sha1 || (lib.downloads && lib.downloads.artifact && lib.downloads.artifact.sha1), size: lib.size });
    classpath.push(dest);
  }

  log('Verificando ' + jobs.length + ' bibliotecas...');
  let feitos = 0;
  await pool(jobs, async j => {
    await download(j.url, j.dest, { sha1: j.sha1, size: j.size, onChunk });
    if (tick) tick(++feitos, jobs.length);
  }, 10);

  // extrai .dll das nativas (pasta limpa: DLL de arquitetura errada quebra o jogo).
  // Se o jogo estiver aberto o Windows trava os arquivos - nesse caso seguimos com o que ja existe.
  try { fs.rmSync(P.natives, { recursive: true, force: true }); }
  catch (e) { log('As bibliotecas do jogo estao em uso (jogo aberto?); mantendo as atuais.'); }
  fs.mkdirSync(P.natives, { recursive: true });
  for (const nj of nativeJars) {
    if (!fs.existsSync(nj)) continue;
    try {
      await extractZip(nj, P.natives, {
        mapName: n => (/\.(dll|so|dylib)$/i.test(n) && !/^META-INF\//.test(n)) ? path.basename(n) : null
      });
    } catch (e) { log('Aviso: ' + path.basename(nj) + ' esta em uso, mantendo o que ja estava.'); }
  }
  return { classpath, nativeJars };
}

/** Baixa o indice de assets e todos os objetos */
async function ensureAssets(vanillaMeta, log, onChunk, tick) {
  const ai = vanillaMeta.assetIndex;
  const idxPath = path.join(P.assets, 'indexes', ai.id + '.json');
  await download(ai.url, idxPath, { sha1: ai.sha1, size: ai.size, onChunk });
  const index = JSON.parse(fs.readFileSync(idxPath, 'utf8'));
  const objects = Object.values(index.objects);
  log('Verificando ' + objects.length + ' arquivos de recursos (sons, idiomas, texturas)...');
  let feitos = 0;
  await pool(objects, async o => {
    const sub = o.hash.slice(0, 2);
    const dest = path.join(P.assets, 'objects', sub, o.hash);
    await download(RESOURCES + sub + '/' + o.hash, dest, { sha1: o.hash, size: o.size, onChunk });
    if (tick) tick(++feitos, objects.length);
  }, 16);
  return ai.id;
}

/** Soma o tamanho do que ainda falta baixar (para a barra de progresso) */
async function estimateBytes(vanillaMeta, fabricProfile) {
  let total = 0;
  total += (vanillaMeta.downloads.client.size || 0);
  for (const lib of vanillaMeta.libraries) {
    if (!allowed(lib.rules)) continue;
    const art = lib.downloads && lib.downloads.artifact;
    if (art) total += art.size || 0;
  }
  total += (vanillaMeta.assetIndex.size || 0);
  return total;
}

module.exports = { ensureVanilla, ensureFabric, ensureLibraries, ensureAssets, allowed, mavenToPath, estimateBytes, nativaDestaMaquina };

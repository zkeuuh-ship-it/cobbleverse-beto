const fs = require('fs');
const path = require('path');

// Escritor NBT minimo, so o suficiente para o servers.dat (formato sem compressao)
function str(s) {
  const b = Buffer.from(s, 'utf8');
  const len = Buffer.alloc(2); len.writeUInt16BE(b.length);
  return Buffer.concat([len, b]);
}

/** Cria/atualiza o servers.dat deixando o servidor do pacote em primeiro lugar. */
function escreverServers(gameDir, servidores) {
  const arquivo = path.join(gameDir, 'servers.dat');
  const partes = [];
  for (const s of servidores) {
    const campos = [
      Buffer.from([8]), str('name'), str(s.name),
      Buffer.from([8]), str('ip'), str(s.ip),
      Buffer.from([1]), str('acceptTextures'), Buffer.from([1]),
      Buffer.from([0]) // fim do compound
    ];
    partes.push(Buffer.concat(campos));
  }
  const qtd = Buffer.alloc(4); qtd.writeInt32BE(servidores.length);
  const lista = Buffer.concat([
    Buffer.from([9]), str('servers'),   // TAG_List "servers"
    Buffer.from([10]), qtd,             // de TAG_Compound
    ...partes
  ]);
  const raiz = Buffer.concat([
    Buffer.from([10]), str(''),         // TAG_Compound raiz
    lista,
    Buffer.from([0])
  ]);
  fs.mkdirSync(gameDir, { recursive: true });
  fs.writeFileSync(arquivo, raiz);
  return arquivo;
}

module.exports = { escreverServers };

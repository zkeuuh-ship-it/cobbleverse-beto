const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pipeline } = require('stream/promises');
const { Readable, Transform } = require('stream');

const UA = 'COBBLEVERSE-Beto-Launcher/1.0';

function hashFile(file, algo) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash(algo);
    fs.createReadStream(file)
      .on('data', d => h.update(d))
      .on('end', () => resolve(h.digest('hex')))
      .on('error', reject);
  });
}
const sha1File = file => hashFile(file, 'sha1');

async function fileOk(file, sha1, size, sha256) {
  try {
    const st = fs.statSync(file);
    if (!st.isFile() || st.size === 0) return false;
    if (size && st.size !== size) return false;
    const algo = sha1 ? 'sha1' : (sha256 ? 'sha256' : null);
    if (!algo) return true;
    const esperado = (sha1 || sha256).toLowerCase();
    if ((await hashFile(file, algo)) === esperado) return true;
    // segunda leitura: antivirus as vezes devolve lixo na primeira, logo apos a gravacao
    await new Promise(r => setTimeout(r, 300));
    return (await hashFile(file, algo)) === esperado;
  } catch (e) { return false; }
}

/**
 * Baixa um arquivo com verificacao de integridade e novas tentativas.
 * onChunk(bytes) e chamado a cada pedaco recebido (para a barra de progresso global).
 */
async function download(url, dest, opts = {}) {
  const { sha1, sha256, onChunk, tries = 4 } = opts;
  const size = opts.size;
  // arquivos grandes precisam de mais tempo em internet lenta (~50 kB/s ainda cabe)
  const timeoutMs = opts.timeoutMs || Math.max(180000, Math.ceil((size || 0) / 20000) * 1000);
  if (await fileOk(dest, sha1, size, sha256)) return { skipped: true, bytes: 0 };
  // se sobrou um arquivo antigo que nao confere, ele sai da frente (senao trava para sempre)
  try { if (fs.existsSync(dest)) fs.unlinkSync(dest); } catch (e) {}

  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const tmp = dest + '.part';
  let lastErr;

  for (let attempt = 1; attempt <= tries; attempt++) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    try {
      const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: ac.signal, redirect: 'follow' });
      if (!res.ok) throw new Error('HTTP ' + res.status + ' em ' + url);

      // O hash e calculado nos bytes que passam pelo stream, nao relendo o disco:
      // antivirus costuma segurar o arquivo recem-escrito e devolver leitura suja.
      const algo = sha1 ? 'sha1' : (sha256 ? 'sha256' : null);
      const esperado = (sha1 || sha256 || '').toLowerCase();
      const hasher = algo ? crypto.createHash(algo) : null;
      let recebido = 0;

      const medidor = new Transform({
        transform(pedaco, enc, cb) {
          recebido += pedaco.length;
          if (hasher) hasher.update(pedaco);
          if (onChunk) onChunk(pedaco.length);
          cb(null, pedaco);
        }
      });

      const reader = Readable.fromWeb(res.body);
      await pipeline(reader, medidor, fs.createWriteStream(tmp));
      clearTimeout(timer);

      if (size && recebido !== size) {
        throw new Error('veio incompleto (' + recebido + ' de ' + size + ' bytes)');
      }
      if (hasher && hasher.digest('hex') !== esperado) {
        throw new Error('o download veio diferente do original (' + algo.toUpperCase() + ')');
      }
      // o que a rede entregou estava certo; confere se foi isso mesmo que ficou gravado
      const noDisco = fs.statSync(tmp).size;
      if (noDisco !== recebido) {
        throw new Error('o arquivo nao foi gravado por inteiro (' + noDisco + ' de ' + recebido +
          ' bytes) - antivirus ou disco cheio');
      }
      fs.renameSync(tmp, dest);
      return { skipped: false, bytes: fs.statSync(dest).size };
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
      try { fs.existsSync(tmp) && fs.unlinkSync(tmp); } catch (_) {}
      if (attempt < tries) await new Promise(r => setTimeout(r, 600 * attempt * attempt));
    }
  }
  throw new Error('Falha ao baixar ' + path.basename(dest) + ': ' + (lastErr && lastErr.message));
}

async function getJSON(url) {
  const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json' } });
  if (!res.ok) throw new Error('HTTP ' + res.status + ' em ' + url);
  return res.json();
}

/** Executa varios downloads com limite de paralelismo. */
async function pool(items, worker, concurrency = 8) {
  const queue = items.slice();
  const errors = [];
  await Promise.all(Array.from({ length: Math.min(concurrency, queue.length || 1) }, async () => {
    while (queue.length) {
      const item = queue.shift();
      try { await worker(item); } catch (e) { errors.push(e); }
    }
  }));
  if (errors.length) throw errors[0];
}

module.exports = { download, getJSON, pool, sha1File, hashFile, fileOk };

const fs = require('fs');
const path = require('path');
const { P, readJSON, writeJSON } = require('./paths');
const { download, pool, fileOk } = require('./net');
const { extractZip } = require('./zip');

// pastas que o launcher gerencia dentro da pasta do jogo
const PASTAS = ['mods', 'resourcepacks', 'shaderpacks', 'datapacks'];
const LAYOUT_ATUAL = 'v2-pastas-separadas';

/** Fontes alternativas do mesmo arquivo (o CDN do CurseForge tem varios enderecos). */
function espelhosDe(url) {
  const lista = [url];
  if (url.includes('mediafilez.forgecdn.net')) lista.push(url.replace('mediafilez.forgecdn.net', 'edge.forgecdn.net'));
  if (url.includes('edge.forgecdn.net')) lista.push(url.replace('edge.forgecdn.net', 'mediafilez.forgecdn.net'));
  return lista;
}

async function baixarComEspelhos(url, dest, opts) {
  let erro;
  for (const end of espelhosDe(url)) {
    try { return await download(end, dest, opts); } catch (e) { erro = e; }
  }
  throw erro;
}

const pastaDe = item => path.join(P.game, item.destino || 'mods');

/**
 * Se o arquivo ja existe em outra pasta gerenciada, move em vez de baixar de novo.
 * (E o que conserta quem instalou pela versao antiga, sem baixar 500 MB outra vez.)
 */
function moverSeEstiverNoLugarErrado(item) {
  const certo = path.join(pastaDe(item), item.file);
  if (fs.existsSync(certo)) return false;
  for (const p of PASTAS) {
    const errado = path.join(P.game, p, item.file);
    if (errado !== certo && fs.existsSync(errado)) {
      try {
        fs.mkdirSync(path.dirname(certo), { recursive: true });
        fs.renameSync(errado, certo);
        return true;
      } catch (e) { return false; }
    }
  }
  return false;
}

/**
 * Deixa cada arquivo do pacote na pasta certa: mods, resourcepacks ou shaderpacks.
 * Resource pack em mods/ nao e carregado pelo jogo - foi assim que os icones do
 * minimapa e as animacoes deixaram de aparecer.
 */
async function syncMods(pack, resourcesDir, log, onChunk) {
  for (const p of PASTAS) fs.mkdirSync(path.join(P.game, p), { recursive: true });

  const esperados = { mods: new Set(), resourcepacks: new Set(), shaderpacks: new Set(), datapacks: new Set() };
  let movidosDeLugar = 0;

  // arquivos que vem dentro do proprio launcher
  for (const b of (pack.bundled || [])) {
    const destino = b.destino || 'mods';
    esperados[destino].add(b.file.toLowerCase());
    const src = path.join(resourcesDir, b.from);
    const dst = path.join(P.game, destino, b.file);
    try {
      if (!fs.existsSync(dst) || fs.statSync(dst).size !== fs.statSync(src).size) fs.copyFileSync(src, dst);
    } catch (e) { log('Aviso: nao consegui copiar ' + b.file + ' (' + e.message + ')'); }
  }

  const faltando = [];
  for (const m of pack.mods) {
    const destino = m.destino || 'mods';
    (esperados[destino] || esperados.mods).add(m.file.toLowerCase());
    if (moverSeEstiverNoLugarErrado(m)) movidosDeLugar++;
    const dest = path.join(pastaDe(m), m.file);
    if (!(await fileOk(dest, m.sha1, m.size))) faltando.push(m);
  }

  if (movidosDeLugar) log(movidosDeLugar + ' arquivo(s) foram para a pasta certa (resource packs e shaders).');

  if (faltando.length) log('Baixando ' + faltando.length + ' arquivos (' + (faltando.reduce((a, b) => a + b.size, 0) / 1048576).toFixed(0) + ' MB)...');
  else log('Todos os ' + pack.mods.length + ' arquivos do pacote ja estao corretos.');

  let feitos = 0;
  await pool(faltando, async m => {
    await baixarComEspelhos(m.url, path.join(pastaDe(m), m.file), { sha1: m.sha1, size: m.size, onChunk });
    feitos++;
    if (feitos % 10 === 0) log('  ' + feitos + '/' + faltando.length + ' baixados...');
  }, 6);

  // mod estranho na pasta mods derruba a conexao com o servidor: sai da frente
  // (resourcepacks/shaderpacks nao sao limpos - o jogador pode ter os proprios)
  const lixo = path.join(P.game, 'mods-removidos');
  let movidos = 0;
  for (const f of fs.readdirSync(P.mods)) {
    if (!/\.(jar|zip)$/i.test(f)) continue;
    if (esperados.mods.has(f.toLowerCase())) continue;
    fs.mkdirSync(lixo, { recursive: true });
    try { fs.renameSync(path.join(P.mods, f), path.join(lixo, f)); movidos++; } catch (e) {}
  }
  if (movidos) log(movidos + ' mod(s) que nao fazem parte do servidor foram para a pasta "mods-removidos".');

  const estado = readJSON(P.state, {});
  if (estado.layout !== LAYOUT_ATUAL) {
    estado.layout = LAYOUT_ATUAL;
    writeJSON(P.state, estado);
    ligarResourcePacks(log, true);
  } else {
    ligarResourcePacks(log, false);
  }
  aplicarKeybinds(pack, log);

  return { baixados: faltando.length, movidos, movidosDeLugar };
}

/**
 * Aplica as teclas remanejadas do pacote, para o jogador nao entrar com atalhos em conflito.
 * Mexe SO nas linhas indicadas; o resto das opcoes (video, som, outras teclas) fica intacto.
 * Roda uma vez por versao: se o jogador reconfigurar depois, nao desfazemos a escolha dele.
 */
function aplicarKeybinds(pack, log) {
  const kb = pack.keybinds;
  if (!kb || !kb.teclas) return;
  const estado = readJSON(P.state, {});
  if (estado.keybinds === kb.versao) return;

  const arquivo = path.join(P.game, 'options.txt');
  if (!fs.existsSync(arquivo)) return; // ainda nao existe: o jogo cria no primeiro boot

  try {
    let txt = fs.readFileSync(arquivo, 'utf8');
    let trocadas = 0;
    for (const [chave, tecla] of Object.entries(kb.teclas)) {
      const re = new RegExp('^' + chave.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':.*$', 'm');
      if (re.test(txt)) {
        const antes = txt;
        txt = txt.replace(re, chave + ':' + tecla);
        if (txt !== antes) trocadas++;
      } else {
        txt = txt.replace(/\s*$/, '\n') + chave + ':' + tecla + '\n';
        trocadas++;
      }
    }
    fs.writeFileSync(arquivo, txt);
    estado.keybinds = kb.versao;
    writeJSON(P.state, estado);
    if (trocadas) log('Teclas ajustadas para nao ficarem em conflito (' + trocadas + ' atalhos).');
  } catch (e) {
    log('Aviso: nao consegui ajustar as teclas (' + e.message + ')');
  }
}

/**
 * Garante que os resource packs do COBBLEVERSE estejam ligados no options.txt.
 * A lista oficial vem do proprio pacote (config/defaultoptions/options.txt).
 * As outras opcoes do jogador (teclas, video, som) nao sao tocadas.
 */
function ligarResourcePacks(log, forcar) {
  try {
    const padrao = path.join(P.game, 'config', 'defaultoptions', 'options.txt');
    const atual = path.join(P.game, 'options.txt');
    if (!fs.existsSync(padrao) || !fs.existsSync(atual)) return;

    const linhaPadrao = (fs.readFileSync(padrao, 'utf8').match(/^resourcePacks:.*$/m) || [])[0];
    if (!linhaPadrao) return;
    const txt = fs.readFileSync(atual, 'utf8');
    const linhaAtual = (txt.match(/^resourcePacks:.*$/m) || [])[0];
    if (!linhaAtual || linhaAtual === linhaPadrao) return;

    // so mexe se houver pack do pacote faltando na lista do jogador
    const doPacote = (linhaPadrao.match(/"file\/[^"]+"/g) || []);
    const faltando = doPacote.filter(p => !linhaAtual.includes(p));
    if (!faltando.length && !forcar) return;

    fs.writeFileSync(atual, txt.replace(/^resourcePacks:.*$/m, linhaPadrao));
    log('Resource packs do COBBLEVERSE ligados (' + faltando.length + ' estavam desligados).');
  } catch (e) {
    log('Aviso: nao consegui ajustar os resource packs (' + e.message + ')');
  }
}

/**
 * Baixa o zip do pacote e extrai configs, shaders e resource packs.
 * Se o download falhar, o jogo ainda funciona (os mods usam as configuracoes padrao),
 * entao avisamos em vez de travar tudo.
 */
async function ensureOverrides(pack, log, onChunk) {
  const ov = pack.overrides;
  if (!ov || !ov.url) return;
  const estado = readJSON(P.state, {});
  if (estado.overrides === ov.marker) { log('Configuracoes do pacote ja instaladas.'); return; }

  const zipPath = path.join(P.cache, 'modpack-' + pack.packVersion.replace(/[^\w.]/g, '_') + '.zip');
  log('Baixando as configuracoes, shaders e resource packs (' + (ov.size / 1048576).toFixed(0) + ' MB)...');
  const enderecos = [ov.url, ...(ov.espelhos || [])];
  let baixou = false, ultimoErro = null;
  for (const end of enderecos) {
    try { await download(end, zipPath, { sha1: ov.sha1, size: ov.size, onChunk, timeoutMs: 1800000 }); baixou = true; break; }
    catch (e) { ultimoErro = e; log('  fonte indisponivel, tentando outra...'); }
  }
  if (!baixou) {
    log('AVISO: nao consegui baixar as configuracoes do pacote (' + (ultimoErro && ultimoErro.message) + ').');
    log('O jogo vai abrir mesmo assim, mas sem os shaders/resource packs do COBBLEVERSE.');
    return;
  }

  const inc = ov.include || [];
  log('Instalando configuracoes e pacotes visuais...');
  await extractZip(zipPath, P.game, {
    mapName: name => {
      if (!name.startsWith('overrides/')) return null;
      const rel = name.slice('overrides/'.length);
      if (!rel) return null;
      const top = rel.split('/')[0];
      if (!inc.includes(top)) return null;
      return rel;
    },
    onFile: (n, i, t) => { if (i % 300 === 0) log('  ' + i + ' arquivos instalados...'); }
  });

  estado.overrides = ov.marker;
  writeJSON(P.state, estado);
  try { fs.unlinkSync(zipPath); } catch (e) {}
  log('Configuracoes instaladas.');
}

module.exports = { syncMods, ensureOverrides, ligarResourcePacks, aplicarKeybinds };

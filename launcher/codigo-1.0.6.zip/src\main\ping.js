const net = require('net');

function varint(n) {
  const b = [];
  do { let t = n & 0x7f; n >>>= 7; if (n !== 0) t |= 0x80; b.push(t); } while (n !== 0);
  return Buffer.from(b);
}
function str(s) { const b = Buffer.from(s, 'utf8'); return Buffer.concat([varint(b.length), b]); }

/** Consulta o status do servidor (jogadores online, motd, ping). */
function pingServidor(host, port, timeout = 5000) {
  return new Promise(resolve => {
    const inicio = Date.now();
    let pronto = false;
    const fim = r => { if (!pronto) { pronto = true; try { sock.destroy(); } catch (e) {} resolve(r); } };
    const sock = net.connect({ host, port });
    sock.setTimeout(timeout);
    sock.on('timeout', () => fim({ online: false }));
    sock.on('error', () => fim({ online: false }));
    sock.on('connect', () => {
      const hs = Buffer.concat([varint(0x00), varint(767), str(host), Buffer.from([port >> 8, port & 0xff]), varint(1)]);
      sock.write(Buffer.concat([varint(hs.length), hs]));
      sock.write(Buffer.from([0x01, 0x00]));
    });
    let buf = Buffer.alloc(0);
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      try {
        let off = 0, len = 0, shift = 0, byte;
        do { if (off >= buf.length) return; byte = buf[off++]; len |= (byte & 0x7f) << shift; shift += 7; } while (byte & 0x80);
        if (buf.length - off < len) return;
        let p = off, id = 0; shift = 0;
        do { byte = buf[p++]; id |= (byte & 0x7f) << shift; shift += 7; } while (byte & 0x80);
        let sl = 0; shift = 0;
        do { byte = buf[p++]; sl |= (byte & 0x7f) << shift; shift += 7; } while (byte & 0x80);
        const j = JSON.parse(buf.slice(p, p + sl).toString('utf8'));
        fim({
          online: true,
          jogadores: j.players ? j.players.online : 0,
          maximo: j.players ? j.players.max : 0,
          versao: j.version ? j.version.name : '',
          ms: Date.now() - inicio,
          lista: (j.players && j.players.sample || []).map(s => s.name)
        });
      } catch (e) { /* aguarda mais dados */ }
    });
  });
}

module.exports = { pingServidor };

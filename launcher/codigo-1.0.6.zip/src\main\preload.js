const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  estado: () => ipcRenderer.invoke('estado'),
  salvarConfig: c => ipcRenderer.invoke('salvar-config', c),
  ping: () => ipcRenderer.invoke('ping'),
  loginMS: () => ipcRenderer.invoke('login-ms'),
  loginSilencioso: () => ipcRenderer.invoke('login-silencioso'),
  loginOffline: nick => ipcRenderer.invoke('login-offline', nick),
  sairConta: () => ipcRenderer.invoke('sair-conta'),
  jogar: conta => ipcRenderer.invoke('jogar', conta),
  jogoAberto: () => ipcRenderer.invoke('jogo-aberto'),
  abrirPasta: qual => ipcRenderer.invoke('abrir-pasta', qual),
  reparar: () => ipcRenderer.invoke('reparar'),
  janela: acao => ipcRenderer.invoke('janela', acao),
  ao: (canal, fn) => {
    const permitidos = ['log', 'log-jogo', 'progresso', 'jogo-fechou', 'launcher-atualizado'];
    if (!permitidos.includes(canal)) return;
    ipcRenderer.on(canal, (e, dados) => fn(dados));
  }
});

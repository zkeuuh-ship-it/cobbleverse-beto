const fs = require('fs');
const path = require('path');
const yauzl = require('yauzl');
const { pipeline } = require('stream/promises');

/**
 * Extrai um .zip com streaming (aguenta arquivos grandes sem estourar memoria).
 * opts.filter(entryName) -> false para pular
 * opts.mapName(entryName) -> caminho relativo de destino, ou null para pular
 * opts.onFile(name, index, total)
 */
function extractZip(zipPath, destDir, opts = {}) {
  const { filter, mapName, onFile } = opts;
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err) return reject(err);
      let count = 0;
      const total = zip.entryCount;
      zip.on('error', reject);
      zip.on('end', () => resolve(count));
      zip.on('entry', entry => {
        const name = entry.fileName;
        let rel = mapName ? mapName(name) : name;
        if (!rel || (filter && !filter(name))) return zip.readEntry();
        // protecao contra zip-slip
        const out = path.resolve(destDir, rel);
        if (!out.startsWith(path.resolve(destDir))) return zip.readEntry();

        if (/\/$/.test(name)) {
          fs.mkdirSync(out, { recursive: true });
          return zip.readEntry();
        }
        zip.openReadStream(entry, async (e2, rs) => {
          if (e2) return reject(e2);
          try {
            fs.mkdirSync(path.dirname(out), { recursive: true });
            await pipeline(rs, fs.createWriteStream(out));
            count++;
            if (onFile) onFile(name, count, total);
            zip.readEntry();
          } catch (e3) { reject(e3); }
        });
      });
      zip.readEntry();
    });
  });
}

module.exports = { extractZip };

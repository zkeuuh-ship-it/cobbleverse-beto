const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');

const { P, ensureDirs, readJSON, writeJSON } = require('./paths');
const { ensureJava } = require('./java');
const mcInst = require('./minecraft');
const { syncMods, ensureOverrides } = require('./pack');
const { iniciarJogo } = require('./launch');
const { escreverServers } = require('./nbt');
const { pingServidor } = require('./ping');
const auth = require('./auth');
const { getJSON } = require('./net');
const { verificarAtualizacao } = require('./autoupdate');

let win = null;
let processoJogo = null;
let instalando = false;

const emDesenvolvimento = !app.isPackaged;
const RES = emDesenvolvimento ? path.join(__dirname, '..', '..', 'resources') : path.join(process.resourcesPath, 'pack');

function carregarPackLocal() {
  return JSON.parse(fs.readFileSync(path.join(RES, 'pack.json'), 'utf8'));
}

/** Usa a lista publicada na internet quando existir; senao a que veio no launcher. */
async function carregarPack(log) {
  const local = carregarPackLocal();
  const cfg = readJSON(P.config, {});
  const url = cfg.manifestUrl || local.manifestUrl;
  if (!url) return local;
  try {
    const remoto = await getJSON(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now());
    if (remoto && Array.isArray(remoto.mods) && remoto.mods.length) {
      if (remoto.packVersion !== local.packVersion) log && log('Pacote atualizado pelo servidor: ' + remoto.packVersion);
      return remoto;
    }
  } catch (e) {
    log && log('Sem conexao com a lista online, usando a lista que veio no launcher.');
  }
  return local;
}

/**
 * A tela inicial tambem precisa do pacote publicado, senao mostra o endereco
 * que veio no instalador - que fica errado assim que o servidor muda de lugar.
 * Guarda por um minuto para nao buscar na rede a cada atualizacao de tela.
 */
let packMemo = null, packMemoEm = 0;
async function packParaTela() {
  if (packMemo && Date.now() - packMemoEm < 60000) return packMemo;
  try {
    packMemo = await carregarPack(null);
    packMemoEm = Date.now();
  } catch (e) {
    packMemo = carregarPackLocal();
    packMemoEm = 0;
  }
  return packMemo;
}

function ramPadrao() {
  const totalMB = Math.floor(os.totalmem() / 1048576);
  if (totalMB >= 16000) return 8192;
  if (totalMB >= 12000) return 6144;
  if (totalMB >= 8000) return 4096;
  return 3072;
}

function criarJanela() {
  win = new BrowserWindow({
    width: 1040, height: 660, minWidth: 940, minHeight: 620,
    frame: false, backgroundColor: '#0d0a1a', show: false,
    icon: path.join(__dirname, '..', '..', 'build', 'icon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.on('closed', () => { win = null; });
}

const VERSAO = process.env.COBBLEVERSE_VERSAO || app.getVersion();

app.whenReady().then(() => {
  ensureDirs();
  gravar('launcher aberto');
  criarJanela();
  // procura atualizacao do launcher em segundo plano (nao trava nada)
  setTimeout(() => {
    verificarAtualizacao(VERSAO, log).then(r => {
      if (!r || !r.atualizou) return;
      // A versao nova so vale quando o programa reabre. Se o jogador ainda nao
      // comecou nada, reabrimos sozinhos - assim ele nunca precisa fazer isso a mao.
      // Se ja reabrimos por causa desta versao e ela voltou a aparecer como "nova",
      // e porque o pacote esta quebrado e o boot desistiu dele. Reabrir de novo so
      // criaria um vai-e-vem sem fim, entao a partir dai fica so o aviso na tela.
      const estado = readJSON(P.state, {});
      const jaTentou = estado.reaberturaVersao === r.versao;
      const podeReabrir = !processoJogo && !instalando && !jaTentou;
      enviar('launcher-atualizado', { versao: r.versao, notas: r.notas, reabrindo: podeReabrir });
      if (jaTentou) log('A versao ' + r.versao + ' nao esta entrando sozinha; deixando como aviso.');
      if (!podeReabrir) return;
      estado.reaberturaVersao = r.versao;
      writeJSON(P.state, estado);
      log('Reabrindo o launcher para aplicar a versao ' + r.versao + '...');
      setTimeout(() => { app.relaunch(); app.exit(0); }, 2500);
    }).catch(() => {});
  }, 2500);
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) criarJanela(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

const enviar = (canal, dados) => { if (win && !win.isDestroyed()) win.webContents.send(canal, dados); };

// tudo que acontece vai para um arquivo, para dar pra investigar problemas depois
let fluxoLog = null;
function arquivoDeLog() {
  if (fluxoLog) return fluxoLog;
  try {
    fs.mkdirSync(P.logs, { recursive: true });
    const nome = 'launcher-' + new Date().toISOString().slice(0, 10) + '.log';
    fluxoLog = fs.createWriteStream(path.join(P.logs, nome), { flags: 'a' });
    const cabecalho = '\n===== ' + new Date().toLocaleString('pt-BR') + ' | launcher ' + VERSAO +
      ' | codigo ' + (process.env.COBBLEVERSE_CODIGO_ATUALIZADO === '1' ? 'atualizado' : 'do instalador') + ' =====\n';
    fluxoLog.write(cabecalho);
  } catch (e) { fluxoLog = null; }
  return fluxoLog;
}
function gravar(txt) {
  const f = arquivoDeLog();
  if (f) { try { f.write('[' + new Date().toLocaleTimeString('pt-BR') + '] ' + txt + '\n'); } catch (e) {} }
}
const log = txt => { gravar(txt); enviar('log', txt); };

process.on('uncaughtException', e => gravar('ERRO NAO TRATADO: ' + (e && e.stack || e)));
process.on('unhandledRejection', e => gravar('PROMESSA REJEITADA: ' + (e && e.stack || e)));

// ---------- estado / configuracao ----------
ipcMain.handle('estado', async () => {
  const cfg = readJSON(P.config, {});
  const pack = await packParaTela();
  const totalMB = Math.floor(os.totalmem() / 1048576);
  return {
    pack: { nome: pack.packName, versao: pack.packVersion, mc: pack.minecraft, loader: pack.fabricLoader, mods: pack.mods.length + (pack.bundled || []).length },
    servidor: pack.server,
    config: {
      ramMB: cfg.ramMB || ramPadrao(),
      entrarDireto: cfg.entrarDireto !== false,
      nickOffline: cfg.nickOffline || '',
      fecharAoJogar: cfg.fecharAoJogar === true
    },
    ramMaximaMB: Math.max(2048, totalMB - 2048),
    contaSalva: cfg.contaMS ? { tipo: 'microsoft', nome: cfg.contaMS.nome, uuid: cfg.contaMS.uuid } : null,
    pasta: P.root,
    versaoLauncher: VERSAO
  };
});

ipcMain.handle('salvar-config', (e, novo) => {
  const cfg = readJSON(P.config, {});
  Object.assign(cfg, novo);
  writeJSON(P.config, cfg);
  return true;
});

ipcMain.handle('ping', async () => {
  const pack = await packParaTela();
  return pingServidor(pack.server.host, pack.server.port);
});

// ---------- contas ----------
ipcMain.handle('login-ms', async () => {
  try { return { ok: true, conta: await auth.loginMicrosoft(win) }; }
  catch (e) { return { ok: false, erro: e.message }; }
});
ipcMain.handle('login-silencioso', async () => {
  const c = await auth.loginSilencioso();
  return c ? { ok: true, conta: c } : { ok: false };
});
ipcMain.handle('login-offline', (e, nick) => {
  try {
    const conta = auth.contaOffline(nick);
    const cfg = readJSON(P.config, {}); cfg.nickOffline = conta.nome; writeJSON(P.config, cfg);
    return { ok: true, conta };
  } catch (err) { return { ok: false, erro: err.message }; }
});
ipcMain.handle('sair-conta', () => { auth.esquecerConta(); return true; });

// ---------- utilidades ----------
ipcMain.handle('abrir-pasta', (e, qual) => {
  const alvo = qual === 'logs' ? P.logs : qual === 'mods' ? P.mods : P.game;
  shell.openPath(alvo);
  return true;
});
ipcMain.handle('janela', (e, acao) => {
  if (!win) return;
  if (acao === 'minimizar') win.minimize();
  if (acao === 'fechar') win.close();
});
ipcMain.handle('reparar', async () => {
  const r = await dialog.showMessageBox(win, {
    type: 'warning', buttons: ['Cancelar', 'Reparar'], defaultId: 1, cancelId: 0,
    title: 'Reparar instalacao',
    message: 'Isso apaga os mods e as configuracoes do pacote e baixa tudo de novo.',
    detail: 'Seus mundos salvos, capturas de tela e sua conta NAO sao apagados.'
  });
  if (r.response !== 1) return false;
  for (const alvo of [P.mods, path.join(P.game, 'config')]) fs.rmSync(alvo, { recursive: true, force: true });
  const estado = readJSON(P.state, {}); delete estado.overrides; writeJSON(P.state, estado);
  return true;
});

// ---------- instalar e jogar ----------
const ETAPAS = [
  ['java', 4], ['minecraft', 4], ['fabric', 1], ['bibliotecas', 8],
  ['recursos', 22], ['configuracoes', 26], ['mods', 34], ['final', 1]
];
const PESO_TOTAL = ETAPAS.reduce((a, b) => a + b[1], 0);

function criarProgresso() {
  let indice = 0, fracao = 0, bytes = 0;
  const mandar = texto => {
    const antes = ETAPAS.slice(0, indice).reduce((a, b) => a + b[1], 0);
    const pct = ((antes + fracao * ETAPAS[indice][1]) / PESO_TOTAL) * 100;
    enviar('progresso', { pct: Math.min(99.5, pct), etapa: ETAPAS[indice][0], texto, mb: (bytes / 1048576).toFixed(0) });
  };
  return {
    etapa(nome, texto) { indice = ETAPAS.findIndex(e => e[0] === nome); fracao = 0; mandar(texto); },
    fracao(f, texto) { fracao = Math.max(0, Math.min(1, f)); mandar(texto); },
    bytes(n) { bytes += n; mandar(); },
    fim() { enviar('progresso', { pct: 100, etapa: 'final', texto: 'Pronto!', mb: (bytes / 1048576).toFixed(0) }); }
  };
}

ipcMain.handle('jogar', async (e, conta) => {
  if (processoJogo) return { ok: false, erro: 'O jogo ja esta aberto.' };
  instalando = true;
  const pr = criarProgresso();
  const onChunk = n => pr.bytes(n);
  try {
    ensureDirs();
    const pack = await carregarPack(log);
    const cfg = readJSON(P.config, {});
    const ramMB = cfg.ramMB || ramPadrao();

    pr.etapa('java', 'Verificando o Java...');
    const javaExe = await ensureJava(pack.javaMajor || 21, log, onChunk,
      (f, t) => pr.fracao(f / t, 'Instalando o Java ' + f + '/' + t));

    pr.etapa('minecraft', 'Baixando o Minecraft ' + pack.minecraft + '...');
    const { meta, jar } = await mcInst.ensureVanilla(pack.minecraft, log, onChunk);

    pr.etapa('fabric', 'Preparando o Fabric...');
    const perfil = await mcInst.ensureFabric(pack.minecraft, pack.fabricLoader, log);

    pr.etapa('bibliotecas', 'Baixando bibliotecas...');
    const { classpath } = await mcInst.ensureLibraries(meta, perfil, log, onChunk,
      (f, t) => pr.fracao(f / t, 'Bibliotecas ' + f + '/' + t));

    pr.etapa('recursos', 'Baixando sons e texturas do jogo...');
    const assetIndexId = await mcInst.ensureAssets(meta, log, onChunk,
      (f, t) => pr.fracao(f / t, 'Recursos ' + f + '/' + t));

    pr.etapa('configuracoes', 'Instalando configuracoes do pacote...');
    await ensureOverrides(pack, log, onChunk);

    pr.etapa('mods', 'Sincronizando os mods do servidor...');
    await syncMods(pack, RES, log, onChunk);

    pr.etapa('final', 'Finalizando...');
    try {
      // se o endereco do servidor mudou, a lista do jogo tem que acompanhar,
      // senao o jogador volta ao menu e ve um servidor que nao existe mais
      const enderecoAtual = pack.server.host + ':' + pack.server.port;
      const listaArquivo = path.join(P.game, 'servers.dat');
      let precisaGravar = true;
      try { precisaGravar = !fs.readFileSync(listaArquivo).includes(enderecoAtual); } catch (e) { precisaGravar = true; }
      if (precisaGravar) {
        escreverServers(P.game, [{ name: pack.server.name || pack.packName, ip: enderecoAtual }]);
        log('Lista de servidores do jogo atualizada para ' + enderecoAtual + '.');
      }
    } catch (err) { log('Aviso: nao consegui salvar a lista de servidores (' + err.message + ')'); }

    log('Abrindo o Minecraft...');
    pr.fim();

    processoJogo = iniciarJogo({
      javaExe, vanillaMeta: meta, fabricProfile: perfil, classpath, clientJar: jar,
      conta, ramMB, assetIndexId,
      entrarDireto: cfg.entrarDireto !== false, servidor: pack.server,
      onLog: l => enviar('log-jogo', l),
      onExit: (code, arquivo) => {
        processoJogo = null;
        gravar('jogo encerrado (codigo ' + code + ') - registro do jogo em ' + arquivo);
        enviar('jogo-fechou', { code, arquivo });
        if (win && !win.isVisible()) win.show();
      }
    });

    // deu tudo certo se o jogo continuar de pe apos alguns segundos
    setTimeout(() => { if (processoJogo && cfg.fecharAoJogar && win) win.minimize(); }, 8000);
    return { ok: true };
  } catch (err) {
    enviar('progresso', { pct: 0, etapa: 'erro', texto: 'Erro', mb: '0' });
    gravar('FALHA NO PREPARO: ' + (err && err.stack || err.message));
    log('ERRO: ' + err.message);
    return { ok: false, erro: err.message };
  } finally {
    instalando = false;
  }
});

ipcMain.handle('jogo-aberto', () => !!processoJogo);
